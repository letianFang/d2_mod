$ErrorActionPreference = 'Stop'

$tablePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\excel\actinfo.txt'
$manifestPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\modinfo.json'

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.name -ne 'FarmHub' -or $manifest.savepath -ne 'FarmHub/') {
    throw 'modinfo.json does not contain the expected values.'
}

$rows = @(Import-Csv -LiteralPath $tablePath -Delimiter "`t")
if ($rows.Count -ne 5) {
    throw "actinfo.txt must contain 5 data rows; found $($rows.Count)."
}

$headers = @((Get-Content -LiteralPath $tablePath -TotalCount 1) -split "`t")
if ($headers.Count -ne 21) {
    throw "actinfo.txt must contain 21 columns; found $($headers.Count)."
}

foreach ($row in $rows) {
    foreach ($column in $headers) {
        if ($null -eq $row.$column) {
            throw "Act $($row.act) is missing column: $column"
        }
    }
}

$act4 = $rows | Where-Object act -eq '4'
$expectedFarmTargets = @(
    'Act 1 - Wilderness 5',
    'Act 1 - Catacombs 2',
    'Act 2 - Arcane',
    'Act 3 - Travincal',
    'Act 3 - Mephisto 2',
    'Act 5 - Baal Temple 2'
)
$actualFarmTargets = 4..9 | ForEach-Object { $act4."waypoint$_" }
if (Compare-Object $expectedFarmTargets $actualFarmTargets) {
    throw 'The Act IV farming destination mapping is incorrect.'
}

$returnActs = @('1', '2', '3', '5')
foreach ($act in $returnActs) {
    $row = $rows | Where-Object act -eq $act
    $hasReturn = 1..9 | Where-Object { $row."waypoint$_" -eq 'Act 4 - Town' }
    if (-not $hasReturn) {
        throw "Act $act has no return slot pointing to the Act IV town."
    }
}

Write-Host 'Verification passed: manifest, table shape, farm targets, and return links are correct.'
