$ErrorActionPreference = 'Stop'

$tablePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\excel\actinfo.txt'
$manifestPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\modinfo.json'
$dataVersionPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\DataVersionBuild.txt'
$mainMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\mainmenupanelhd.json'
$travincalPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\env\preset\act3\travincal\travn.json'
$quickStartSpritePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\global\ui\panel\message\QuickStart.sprite'
$quickStartLowEndSpritePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\global\ui\panel\message\QuickStart.lowend.sprite'
$pauseMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\pauselayouthd.json'
$gardenPauseMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\pauselayoutgardenhd.json'

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.name -ne 'FarmHub' -or $manifest.savepath -ne '../') {
    throw 'modinfo.json does not contain the expected values.'
}

$dataVersionBytes = [System.IO.File]::ReadAllBytes($dataVersionPath)
$expectedDataVersionBytes = [System.Text.Encoding]::ASCII.GetBytes('93854')
if ($dataVersionBytes.Length -ne $expectedDataVersionBytes.Length -or
    (Compare-Object $dataVersionBytes $expectedDataVersionBytes -SyncWindow 0)) {
    throw 'DataVersionBuild.txt must be exactly five ASCII bytes: 93854 (no BOM or newline).'
}

$rows = @(Import-Csv -LiteralPath $tablePath -Delimiter "`t")
if ($rows.Count -ne 5) {
    throw "actinfo.txt must contain 5 data rows; found $($rows.Count)."
}

$headers = @((Get-Content -LiteralPath $tablePath -TotalCount 1) -split "`t")
if ($headers.Count -ne 21) {
    throw "actinfo.txt must contain 21 columns; found $($headers.Count)."
}

foreach ($row in $rows) {
    foreach ($column in $headers) {
        if ($null -eq $row.$column) {
            throw "Act $($row.act) is missing column: $column"
        }
    }
}

$act4 = $rows | Where-Object act -eq '4'
$expectedFarmTargets = @(
    'Act 1 - Wilderness 5',
    'Act 1 - Catacombs 2',
    'Act 2 - Arcane',
    'Act 3 - Travincal',
    'Act 3 - Mephisto 2',
    'Act 5 - Baal Temple 2'
)
$actualFarmTargets = 4..9 | ForEach-Object { $act4."waypoint$_" }
if (Compare-Object $expectedFarmTargets $actualFarmTargets) {
    throw 'The Act IV farming destination mapping is incorrect.'
}

$returnActs = @('1', '2', '3', '5')
foreach ($act in $returnActs) {
    $row = $rows | Where-Object act -eq $act
    $hasReturn = 1..9 | Where-Object { $row."waypoint$_" -eq 'Act 4 - Town' }
    if (-not $hasReturn) {
        throw "Act $act has no return slot pointing to the Act IV town."
    }
}

$mainMenuText = Get-Content -LiteralPath $mainMenuPath -Raw
if ($mainMenuText -notmatch 'CharacterSelect:LoadCharacter:2' -or
    $mainMenuText -notmatch 'PANEL\\\\message\\\\QuickStart') {
    throw 'The character-select quick Hell configuration is missing or incorrect.'
}
$quickHellMatches = [regex]::Matches($mainMenuText, 'CharacterSelect:LoadCharacter:2')
if ($quickHellMatches.Count -ne 1 -or $mainMenuText -match '点击角色快速开始|点击角色快速开房') {
    throw 'The character-select layout must contain one invisible Hell shortcut and no visible quick-start label.'
}

foreach ($currentPauseMenuPath in @($pauseMenuPath, $gardenPauseMenuPath)) {
    $pauseMenuText = Get-Content -LiteralPath $currentPauseMenuPath -Raw
    if ($pauseMenuText -notmatch '"type"\s*:\s*"ButtonWidget"\s*,\s*"name"\s*:\s*"FastExitBackground"' -or
        $pauseMenuText -notmatch '(?s)"name"\s*:\s*"FastExitBackground".*?"fitToParent"\s*:\s*true.*?"onClickMessage"\s*:\s*"PausePanelMessage:ExitGame"') {
        throw "The pause-menu background quick-exit configuration is missing or incorrect: $currentPauseMenuPath"
    }
}

$travincalInfo = Get-Item -LiteralPath $travincalPath
if ($travincalInfo.Length -lt 1000000) {
    throw 'The Travincal open-layout file is missing or unexpectedly small.'
}

foreach ($spritePath in @($quickStartSpritePath, $quickStartLowEndSpritePath)) {
    $spriteBytes = [System.IO.File]::ReadAllBytes($spritePath)
    if ($spriteBytes.Length -lt 4 -or
        [System.Text.Encoding]::ASCII.GetString($spriteBytes, 0, 4) -ne 'SPa1') {
        throw "Invalid quick-start sprite: $spritePath"
    }
}

Write-Host 'Verification passed: version, mappings, Travincal layout, character-click Hell shortcut, and pause-menu quick exit are correct.'
