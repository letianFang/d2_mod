# FarmHub：第四幕刷宝传送枢纽

这是一个用于《暗黑破坏神 II：狱火重生》（D2R）离线模式的数据模组。它补满第四幕传送点菜单的 9 个固定槽位，并在其他各幕保留一条返回第四幕城镇（群魔堡垒）的通路。

## 第四幕传送点菜单

| 槽位 | 目的地 | 用途 |
| --- | --- | --- |
| 1 | 群魔堡垒 | 第四幕城镇 |
| 2 | 绝望平原 | 衣卒尔 |
| 3 | 火焰之河 | 海法斯特、迪亚波罗路线 |
| 4 | 黑色荒地 | 女伯爵钥匙/符文 |
| 5 | 地下墓穴第二层 | 安达利尔 |
| 6 | 神秘避难所 | 召唤者钥匙 |
| 7 | 崔凡克 | 议会成员 |
| 8 | 憎恨囚牢第二层 | 墨菲斯托 |
| 9 | 世界之石要塞第二层 | 巴尔路线 |

新增目的地仍沿用原版传送点的解锁状态；角色必须在当前难度中取得对应传送点后才能点击它。

## 跨幕返回映射

为了从其他幕的列表直接返回第四幕城镇，以下低价值槽位被替换：

| 幕 | 被替换的原传送点 | 新目的地 |
| --- | --- | --- |
| 第一幕 | 监牢第一层 | 群魔堡垒 |
| 第二幕 | 皇宫监牢第一层 | 群魔堡垒 |
| 第三幕 | 庞大湿地 | 群魔堡垒 |
| 第五幕 | 冰冻苔原 | 群魔堡垒 |

原场景里的传送点物件没有被删除，仍可用于离开该场景；只是它不再出现在城镇传送点菜单中，因而不能从城镇直接返回。

## 安装

方法一（自动复制）：

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -D2RPath "C:\你的路径\Diablo II Resurrected"
```

方法二（手动复制）：把本工程中的 `mods\FarmHub` 整个复制到 D2R 安装目录，使最终路径为：

```text
Diablo II Resurrected\mods\FarmHub\FarmHub.mpq\modinfo.json
Diablo II Resurrected\mods\FarmHub\FarmHub.mpq\data\global\excel\actinfo.txt
```

然后给 Battle.net 或游戏快捷方式添加启动参数：

```text
-mod FarmHub -txt
```

## 存档、设置与联机注意事项

- 仅用于离线模式，不要带着数据模组进入战网角色。
- `modinfo.json` 使用 `savepath: "../"`，直接沿用原版角色、`Settings.json` 和 `Custom.key`，因此启动模组后键位与快速施法设置不会另起一套。
- 已经取得的传送点状态保存在角色的当前难度记录里；模组不会自动替你解锁刷宝点。
- 本模组完整覆盖 `actinfo.txt`。与其他也修改该表的模组一起使用时，需要手工合并。

国服客户端的默认配置目录通常是 `Saved Games\Diablo II Resurrected (CN)`；国际服通常是 `Saved Games\Diablo II Resurrected`。本模组会自动使用当前客户端对应的默认目录。

## 自检

在工程根目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\verify.ps1
```

该脚本会检查 JSON、TSV 列数、第四幕 6 个新增目的地，以及第一、二、三、五幕的返回通路。

## 实现说明

模组只重排 `actinfo.txt` 中每幕的 `waypoint1` 至 `waypoint9`。关卡数据、任务、怪物、地图和传送点物件都没有改动，因此目的地保持原版落点和解锁逻辑。由于 D2R 每幕传送点界面最多只有 9 个固定槽位，这种方式不会真正创建第 10 个以上的传送点。
