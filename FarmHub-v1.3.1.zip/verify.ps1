$ErrorActionPreference = 'Stop'

$tablePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\excel\actinfo.txt'
$manifestPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\modinfo.json'
$dataVersionPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\DataVersionBuild.txt'
$mainMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\mainmenupanelhd.json'
$travincalPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\env\preset\act3\travincal\travn.json'
$quickStartSpritePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\global\ui\panel\message\QuickStart.sprite'
$quickStartLowEndSpritePath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\hd\global\ui\panel\message\QuickStart.lowend.sprite'
$pauseMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\pauselayouthd.json'
$gardenPauseMenuPath = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq\data\global\ui\layouts\pauselayoutgardenhd.json'

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.name -ne 'FarmHub' -or $manifest.savepath -ne '../') {
    throw 'modinfo.json does not contain the expected values.'
}

$dataVersionBytes = [System.IO.File]::ReadAllBytes($dataVersionPath)
$expectedDataVersionBytes = [System.Text.Encoding]::ASCII.GetBytes('93854')
if ($dataVersionBytes.Length -ne $expectedDataVersionBytes.Length -or
    (Compare-Object $dataVersionBytes $expectedDataVersionBytes -SyncWindow 0)) {
    throw 'DataVersionBuild.txt must be exactly five ASCII bytes: 93854 (no BOM or newline).'
}

$rows = @(Import-Csv -LiteralPath $tablePath -Delimiter "`t")
if ($rows.Count -ne 5) {
    throw "actinfo.txt must contain 5 data rows; found $($rows.Count)."
}

$headers = @((Get-Content -LiteralPath $tablePath -TotalCount 1) -split "`t")
if ($headers.Count -ne 21) {
    throw "actinfo.txt must contain 21 columns; found $($headers.Count)."
}

foreach ($row in $rows) {
    foreach ($column in $headers) {
        if ($null -eq $row.$column) {
            throw "Act $($row.act) is missing column: $column"
        }
    }
}

$act4 = $rows | Where-Object act -eq '4'
$expectedFarmTargets = @(
    'Act 1 - Wilderness 5',
    'Act 1 - Catacombs 2',
    'Act 2 - Arcane',
    'Act 3 - Travincal',
    'Act 3 - Mephisto 2',
    'Act 5 - Baal Temple 2'
)
$actualFarmTargets = 4..9 | ForEach-Object { $act4."waypoint$_" }
if (Compare-Object $expectedFarmTargets $actualFarmTargets) {
    throw 'The Act IV farming destination mapping is incorrect.'
}

$returnActs = @('1', '2', '3', '5')
foreach ($act in $returnActs) {
    $row = $rows | Where-Object act -eq $act
    $hasReturn = 1..9 | Where-Object { $row."waypoint$_" -eq 'Act 4 - Town' }
    if (-not $hasReturn) {
        throw "Act $act has no return slot pointing to the Act IV town."
    }
}

$mainMenuText = Get-Content -LiteralPath $mainMenuPath -Raw
if ($mainMenuText -notmatch 'CharacterSelect:LoadCharacter:2' -or
    $mainMenuText -notmatch '"name"\s*:\s*"InvisibleHellStart"' -or
    $mainMenuText -notmatch 'PANEL\\\\message\\\\QuickStart') {
    throw 'The character-select quick Hell configuration is missing or incorrect.'
}
$quickHellMatches = [regex]::Matches($mainMenuText, 'CharacterSelect:LoadCharacter:2')
if ($quickHellMatches.Count -ne 1 -or
    $mainMenuText -match '点击角色快速开始|点击角色快速开房|focusIndicatorFilename') {
    throw 'The character-select layout must contain one invisible Hell shortcut and no visible quick-start label.'
}

$expectedTransparentSpriteHashes = @{
    $quickStartSpritePath = '6239C8950ACE6EBBA481A662175BD121222B2ED3069E95A0CD009078769D2917'
    $quickStartLowEndSpritePath = 'A40B272002F7FE18B91C9EB841DF5C100B321DE5651AABF9394EFE37D9E2D12E'
}
foreach ($spritePath in $expectedTransparentSpriteHashes.Keys) {
    $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $spritePath).Hash
    if ($actualHash -ne $expectedTransparentSpriteHashes[$spritePath]) {
        throw "The quick-start sprite is not the expected fully transparent image: $spritePath"
    }
}

foreach ($currentPauseMenuPath in @($pauseMenuPath, $gardenPauseMenuPath)) {
    $pauseMenuText = Get-Content -LiteralPath $currentPauseMenuPath -Raw
    if ($pauseMenuText -notmatch '"type"\s*:\s*"ButtonWidget"\s*,\s*"name"\s*:\s*"FastExitBackground"' -or
        $pauseMenuText -notmatch '(?s)"name"\s*:\s*"FastExitBackground".*?"fitToParent"\s*:\s*true.*?"onClickMessage"\s*:\s*"PausePanelMessage:ExitGame"') {
        throw "The pause-menu background quick-exit configuration is missing or incorrect: $currentPauseMenuPath"
    }
}

$travincalInfo = Get-Item -LiteralPath $travincalPath
if ($travincalInfo.Length -lt 1000000) {
    throw 'The Travincal open-layout file is missing or unexpectedly small.'
}

$navigation = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'navigation-assets.json') -Raw | ConvertFrom-Json
$modRoot = Join-Path $PSScriptRoot 'mods\FarmHub\FarmHub.mpq'
foreach ($removedFile in $navigation.removedFiles) {
    if (Test-Path -LiteralPath (Join-Path $modRoot $removedFile)) {
        throw "Removed navigation override still exists: $removedFile"
    }
}
foreach ($file in $navigation.files.PSObject.Properties) {
    $assetPath = Join-Path $modRoot $file.Name
    if ((Get-FileHash -LiteralPath $assetPath -Algorithm SHA256).Hash -ne $file.Value) {
        throw "Navigation asset hash mismatch: $($file.Name)"
    }
}
foreach ($tile in $navigation.entranceTiles) {
    $scene = Get-Content -LiteralPath (Join-Path $modRoot "data/hd/roomtiles/$tile.json") -Raw | ConvertFrom-Json
    $beam = @($scene.entities | Where-Object name -eq 'FarmHubEntranceBeam')
    if ($beam.Count -ne 1 -or $beam[0].components.filename -notcontains 'data/hd/vfx/particles/overlays/object/horadric_light/fx_horadric_light.particles') {
        throw "Entrance beam missing: $tile"
    }
    if ($scene.entities.components.prefab -notcontains 'data/hd/env/porory/beacon/pf_beacon_downstairs.json') {
        throw "Entrance beacon missing: $tile"
    }
}
foreach ($direction in $navigation.directionAngles.PSObject.Properties) {
    $scene = Get-Content -LiteralPath (Join-Path $modRoot "data/hd/env/preset/expansion/wildtemple/nihl$($direction.Name).json") -Raw | ConvertFrom-Json
    $arrows = @($scene.entities | Where-Object name -like 'FarmHubNihlathakArrow*')
    $particle = "data/hd/directionarrows/particles/directionarrows_$($direction.Value).particles"
    if ($arrows.Count -ne 11 -or @($arrows.id | Select-Object -Unique).Count -ne 11) {
        throw "Nihlathak arrows are missing or have duplicate IDs: $($direction.Name)"
    }
    foreach ($arrow in $arrows) {
        if ($arrow.components.filename -notcontains $particle) {
            throw "Incorrect Nihlathak direction: $($direction.Name)"
        }
    }
    if ($scene.dependencies.particles.path -notcontains $particle) {
        throw "Nihlathak particle dependency missing: $($direction.Name)"
    }
}
Write-Host 'Verification passed: existing FarmHub features, entrance beams/beacons, four Nihlathak arrow variants, and navigation asset hashes.'
